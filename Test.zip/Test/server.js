const express = require('express');
var bodyParser = require('body-parser');
const app = express();
const RandomUser = require('./index');

app.use(express.json());
app.use(bodyParser.json()); // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true })); // support encoded bodies




app.get('/getuser',async(req,res)=>{
   new RandomUser().format('json').count(100).nationality('nl').retrieve()
   .then( (data1)=>  res.status(200).send(data1))
   .catch((error)=>(console.log(error.message)));
 
});


const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Server Listening on port ${port}...`));