const mongoose = require ('mongoose');
const joi = require ('@hapi/joi');
joi.objectid = require('joi-objectid');

const studentSchema = new mongoose.Schema({
  studentId:{
      type:Number,
      required : true
  },
studentName:{
    type:Number,
    minlength :2,
    maxlength :20,
    required : true
},
email:{
    type:String,
    required : true
},
password:{
    type:String,
    required : true
},
mobile:{
    type : Number,
    minlength : 10,
    maxlength :15,
    required :true
}  
},{timestamps :true});
const Student = mongoose.model('Student',studentSchema);

function validateStudent(student){
    const Schema = joi.object().keys({
  studentId : joi.string().required(),
  studentName : joi.string().min(2).max(20).required(),
  email : joi.string().required(),
  mobile : joi.number().min(10).max(15).required(),
  password:joi.string().required(),
 
})
return {error} = schema.validate(student);
}

// studentSchema.method.generateAuthToken = function(){
//     const token = jwt.sign({_id : this._id,email:this.email})
//     return token;
// }
module.exports.Student =  Student;
module.exports.validateStudent = validateStudent;