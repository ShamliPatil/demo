const {Student , validateStudent} = require ('../model/student');
const joi = require ('@hapi/joi');
joi.objectid = require('joi-objectid');
const bcrypt = require ('bcrypt');

const express = require('express');
const router = express.Router();

router.post('/AddStudent',async (req,res) =>{
    const { error } =  validateStudent(req.body);
    if(error) return res.status(400).send({statusCode:400,error:'Bad Request', message: error.message });
    let student = await Student.findOne({email : req.body.eamil});
    if(!student)return res.status(400).send({statusCode:400,error:'Bad Request', message: 'User Aleardy exits' });
    student = new Student(req.body);
    student = await student.save();
    return res.status(200).send({statusCode:200,message: 'Student Add Successfully'});

});
router.post('/auth',async (req,res) =>{
    const { error } =  validate(req.body);
    if(error) return res.status(400).send({statusCode:400,error:'Bad Request', message: error.message });
    let student = await Student.findOne({email : req.body.eamil});
    if(!student)return res.status(400).send({statusCode:400,error:'Bad Request', message: 'User Not Found' });
    const validpassword = bcrypt.compare(req.body.password,student.password);
    if(!validpassword)return res.status(400).send({statusCode:400,error:'Bad Request', message: 'Invalid Student Email or Password' });
    const token = generateToken(student);
    student = await student.save();
    return res.status(200).send({statusCode:200,message: 'Student Add Successfully',StudentToken : token});

}); 

function validate(req){
    const schema = joi.object().keys()({
        email : joi.string().required(),
        password:joi.string().required(),
    })
    return {error} = schema.validate;
}

function generateToken(student){
    const token = jwt.sign({_id : this._id,email:this.email})
     return token;
}

module.exports = router;