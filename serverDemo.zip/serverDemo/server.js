//Importing dependencies
const express = require('express');
var path = require('path');
const app = express();
const student = require ('./routes/student');
const db = require ('./config/db')();

app.use('/api',student)
//Starting server on port 8081
const port = process.env.PORT || 4800;
app.listen(port, () => {
    console.log('Server started!');
    console.log(`on port ${port}`);
});